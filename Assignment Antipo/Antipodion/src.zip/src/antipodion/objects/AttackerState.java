/*
 * AttackerState.java
 *
 * Created on 18 August 2007, 16:19
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package antipodion.objects;

/**
 *
 * @author phingsto
 */
public enum AttackerState
{
    WAITING, CHARGING, RETURNING
}

