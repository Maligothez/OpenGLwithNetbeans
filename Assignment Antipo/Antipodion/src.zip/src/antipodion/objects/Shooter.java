/*
 * Shooter.java
 *
 * Created on 18 August 2007, 12:15
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package antipodion.objects;

/**
 *
 * @author phingsto
 */
public interface Shooter extends SimObject
{
    public void reload();
}
