/*
 * SimObject.java
 *
 * Created on 16 August 2007, 20:45
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package antipodion.objects;

/**
 *
 * @author phingsto
 */
public interface SimObject
{    
    public void update(long elapsed);
}
