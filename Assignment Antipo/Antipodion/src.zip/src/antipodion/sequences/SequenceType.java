package antipodion.sequences;

/**
 *
 * @author phingsto
 */
public enum SequenceType
{
    EXPLOSION,
    ATTACKER_DEATH
}
